import React from "react";
import { createRoot } from "react-dom/client";
import FacilityPro from "./FacilityPro.jsx";

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <FacilityPro />
  </React.StrictMode>
);
